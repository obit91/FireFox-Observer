# FireFox-Observer
Easily see which information is stored on you, for the current active session.

## Debugging:
about:debugging#/runtime/this-firefox

### TODO:
* Run the permissions code from within the active tab (instead of the extension, inject it).
* Attempt to retrieve the trackers from the browser, instead of calculating them manually.
* Extra - create a better looking UI for the cookies.